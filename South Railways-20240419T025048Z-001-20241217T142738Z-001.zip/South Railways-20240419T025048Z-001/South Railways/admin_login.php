<?php
// admin_login.php

// Start session
session_start();

// Check if admin is already logged in
if(isset($_SESSION["admin_logged_in"]) && $_SESSION["admin_logged_in"] === true) {
    // Redirect to admin dashboard
    header("location: admin_dashboard.php");
    exit;
}

// Check if form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check credentials (replace with actual admin credentials)
    $admin_username = "admin";
    $admin_password = "adminpassword";

    if($_POST["username"] == $admin_username && $_POST["password"] == $admin_password) {
        // Admin login successful, set session variables
        $_SESSION["admin_logged_in"] = true;
        
        // Redirect to admin dashboard
        header("location: admin_dashboard.php");
        exit;
    } else {
        // Invalid credentials
        $error_message = "Invalid username or password.";
    }
}
?>
