<?php
// Assuming your database credentials
$servername = "localhost";
$username ="root";
$password = "";
$dbname = "rail";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Escape user inputs for security
  $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
  $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
  $train_id = mysqli_real_escape_string($conn, $_POST['train_id']);
  $class_type = mysqli_real_escape_string($conn, $_POST['class_type']);
  $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);
  $num_passengers = mysqli_real_escape_string($conn, $_POST['number_of_passengers']);
  
  // Insert user data into database
  $sql = "INSERT INTO bookings (booking_id, user_id, train_id, class_type, booking_date, number_of_passengers)
  VALUES ('$booking_id', '$user_id', '$train_id', '$class_type', '$booking_date', '$num_passengers')";

  if ($conn->query($sql) === TRUE) {
    echo "Ticket booked successfully!";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close connection
$conn->close();
?>
