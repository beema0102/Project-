<?php
// view_booking.php

// Add your database connection code here (e.g., include db_connect.php)
include 'config.php';
// Check if user is logged in (replace with actual authentication logic)
if(!isset($_SESSION["customer_logged_in"]) || $_SESSION["customer_logged_in"] !== true) {
    // Redirect to login page
    header("location: customer_login.php");
    exit;
}

// Retrieve and display booking details for the logged-in customer
?>
