-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2024 at 07:50 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rail`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `train_id` int(11) DEFAULT NULL,
  `class_type` enum('General','AC') DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `number_of_passengers` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `passenger_details`
--

CREATE TABLE `passenger_details` (
  `passenger_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `passenger_name` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `trains`
--

CREATE TABLE `trains` (
  `train_id` int(11) NOT NULL,
  `train_number` varchar(20) DEFAULT NULL,
  `train_name` varchar(255) DEFAULT NULL,
  `starting_point` varchar(100) DEFAULT NULL,
  `ending_point` varchar(100) DEFAULT NULL,
  `intermediate_station1` varchar(100) DEFAULT NULL,
  `intermediate_station2` varchar(100) DEFAULT NULL,
  `intermediate_station3` varchar(100) DEFAULT NULL,
  `intermediate_station4` varchar(100) DEFAULT NULL,
  `intermediate_station5` varchar(100) DEFAULT NULL,
  `arrival_time_at_station1` time DEFAULT NULL,
  `arrival_time_at_station2` time DEFAULT NULL,
  `arrival_time_at_station3` time DEFAULT NULL,
  `arrival_time_at_station4` time DEFAULT NULL,
  `arrival_time_at_station5` time DEFAULT NULL,
  `available_days` varchar(7) DEFAULT NULL,
  `seating_capacity_class1` int(11) DEFAULT NULL,
  `seating_capacity_class2` int(11) DEFAULT NULL,
  `seating_capacity_class3` int(11) DEFAULT NULL,
  `rate_general` decimal(10,2) DEFAULT 0.00,
  `rate_ac` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trains`
--

INSERT INTO `trains` (`train_id`, `train_number`, `train_name`, `starting_point`, `ending_point`, `intermediate_station1`, `intermediate_station2`, `intermediate_station3`, `intermediate_station4`, `intermediate_station5`, `arrival_time_at_station1`, `arrival_time_at_station2`, `arrival_time_at_station3`, `arrival_time_at_station4`, `arrival_time_at_station5`, `available_days`, `seating_capacity_class1`, `seating_capacity_class2`, `seating_capacity_class3`, `rate_general`, `rate_ac`) VALUES
(1, 'TN123', 'Chennai Express', 'Chennai', 'Bangalore', 'Vellore', 'Salem', 'Erode', 'Coimbatore', 'Palakkad', '08:00:00', '10:30:00', '12:00:00', '14:30:00', '16:00:00', '1111100', 100, 150, 200, '500.00', '1000.00'),
(2, 'KL456', 'Malabar Express', 'Trivandrum', 'Mangalore', 'Kollam', 'Alappuzha', 'Ernakulam', 'Thrissur', 'Calicut', '09:00:00', '11:30:00', '13:00:00', '15:30:00', '17:00:00', '1111110', 120, 180, 220, '300.00', '600.00'),
(3, 'KA789', 'Mysore Express', 'Bangalore', 'Mysore', 'Mandya', 'Srirangapatna', 'Pandavapura', 'Mandya', 'Ramanagaram', '10:00:00', '12:30:00', '14:00:00', '16:30:00', '18:00:00', '1101011', 80, 120, 150, '200.00', '400.00'),
(4, 'AP012', 'Golconda Express', 'Hyderabad', 'Chennai', 'Secunderabad', 'Kurnool', 'Nellore', 'Vijayawada', 'Ongole', '08:30:00', '11:00:00', '13:30:00', '15:00:00', '17:30:00', '1001100', 90, 140, 180, '400.00', '800.00'),
(5, 'TS345', 'Telangana Express', 'Hyderabad', 'Visakhapatnam', 'Warangal', 'Khammam', 'Vijayawada', 'Rajahmundry', 'Samalkot', '09:30:00', '12:00:00', '14:30:00', '16:00:00', '18:30:00', '0111110', 110, 160, 200, '450.00', '900.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_type` enum('admin','customer') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `user_type`) VALUES
(1, 'admin', 'adminpassword', 'admin@example.com', 'admin'),
(2, 'bobby', 'bobby', 'bobby@example.com', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `train_id` (`train_id`);

--
-- Indexes for table `passenger_details`
--
ALTER TABLE `passenger_details`
  ADD PRIMARY KEY (`passenger_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `trains`
--
ALTER TABLE `trains`
  ADD PRIMARY KEY (`train_id`),
  ADD UNIQUE KEY `train_number` (`train_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `passenger_details`
--
ALTER TABLE `passenger_details`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trains`
--
ALTER TABLE `trains`
  MODIFY `train_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`train_id`) REFERENCES `trains` (`train_id`);

--
-- Constraints for table `passenger_details`
--
ALTER TABLE `passenger_details`
  ADD CONSTRAINT `passenger_details_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
