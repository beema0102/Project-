<?php
// Include database configuration file
include 'config.php';

// Check if form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input (example validation, implement proper validation)
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Prepare and execute SQL statement to check if user exists
    $sql = "SELECT * FROM users WHERE username = ?";
    if($stmt = $conn->prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt->bind_param("s", $param_username);

        // Set parameters
        $param_username = $username;

        // Attempt to execute the prepared statement
        if($stmt->execute()){
            // Store result
            $stmt->store_result();

            if($stmt->num_rows == 1){
                // User exists, fetch and verify password
                $stmt->bind_result($id, $db_username, $db_password, $db_email, $db_user_type);
                if($stmt->fetch()){
                    if(password_verify($password, $db_password)){
                        // Password is correct, redirect to customer dashboard
                        header("location: customer_dashboard.html");
                        exit;
                    } else {
                        // Invalid password
                        $error_message = "Invalid username or password.";
                    }
                }
            } else {
                // User does not exist
                $error_message = "User does not exist.";
            }
        } else {
            // Database query failed
            $error_message = "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}
?>

